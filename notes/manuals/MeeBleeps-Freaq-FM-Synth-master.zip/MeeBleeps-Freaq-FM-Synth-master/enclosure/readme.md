Added awesome 3D printed enclosure files created by https://www.reddit.com/user/PollutionExpensive43/ - THANKS!
