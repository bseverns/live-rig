var searchData=
[
  ['char2mozzi_2epy',['char2mozzi.py',['../char2mozzi_8py.html',1,'']]]
];
